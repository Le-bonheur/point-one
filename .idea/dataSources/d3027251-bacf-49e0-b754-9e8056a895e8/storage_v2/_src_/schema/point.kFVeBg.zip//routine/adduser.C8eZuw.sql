create procedure addUser()
  begin
    declare userId char(10) default '1000000000';
    declare table_id int default 0;
    declare v_age int default 20;
    declare v_country char(10) default '中国';
    declare v_city char(10) default '深圳';
    declare v_university char(10) default '北京邮电大学';
    declare v_major char(10) default '计算机科学';
    declare v_school char(10) default '深圳外国语学校';
    declare v_company char(10) default '深圳xxx公司';
    declare v_occupation char(10) default '程序员';

    while convert(right(userId, 5), signed) < 10000 do

      set v_country = '中国';
      set v_city = '深圳';
      set v_university = '北京邮电大学';
      set v_major = '计算机科学';
      set v_school = '深圳外国语学校';
      set v_company = '深圳xxx公司';
      set v_occupation = '程序员';

      if mod(table_id, 2) = 0
      then
        set v_country = '中国';
        set v_city = '北京';
      end if;

      if mod(table_id, 12) = 0
      then
        set v_country = '韩国';
        set v_city = '首尔';
      end if;

      if mod(table_id, 3) = 0
      then
        set v_university = '深圳大学';
        set v_major = '心理学';
      end if;

      if mod(table_id, 5) = 0
      then
        set v_school = '深圳中学';
      end if;

      if mod(table_id, 4) = 0
      then
        set v_company = '北京xxx公司';
        set v_occupation = '产品经理';
      end if;

      set v_age = floor(19 + (rand() * (30 - 20)));

      INSERT INTO user (id, user_id, nickname, age, country, city,
                        university, major, school, company, occupation, create_time, update_time)
      VALUES (table_id, userId, concat('用户', table_id), v_age, v_country, v_city,
                        v_university, v_major, v_school, v_school, v_occupation, CURRENT_TIMESTAMP(),
              CURRENT_TIMESTAMP());

      set table_id = table_id + 1;
      set userId = concat('10000', lpad(table_id, 5, '0'));

      if mod(table_id, 1000) = 0
      then
        commit;
      end if;

    end while;
    commit;
  end;

